from asset_manager import BundleExtractor, AssetManagerError

def jalankan_demo():
    try:
        # Inisialisasi library
        # Pastikan AssetBundleExtractor.exe ada di folder /assets/
        extractor = BundleExtractor()
        
        # Ganti 'contoh_file.unity3d' dengan file yang ingin kamu tes
        hasil = extractor.extract("target_file.unity3d", "./hasil_ekstrak")
        print("Selesai!")
        
    except AssetManagerError as e:
        print(f"Ada masalah pada library: {e}")
    except Exception as e:
        print(f"Masalah sistem: {e}")

if __name__ == "__main__":
    jalankan_demo()
