import subprocess
import os
from .exceptions import ExecutableNotFoundError

class BundleExtractor:
    def __init__(self, exe_path=None):
        # Jika tidak diisi, cari di folder default library
        if exe_path is None:
            base_dir = os.path.dirname(os.path.dirname(__file__))
            self.exe_path = os.path.join(base_dir, "assets", "AssetBundleExtractor.exe")
        else:
            self.exe_path = exe_path

        if not os.path.exists(self.exe_path):
            raise ExecutableNotFoundError(f"File {self.exe_path} tidak ditemukan!")

    def extract(self, input_file, output_dir):
        """Memanggil .exe untuk melakukan ekstraksi"""
        print(f"🚀 Memproses: {input_file}...")
        
        # Contoh perintah CLI (sesuaikan dengan command .exe-nya)
        command = [self.exe_path, "extract", input_file, output_dir]
        
        try:
            result = subprocess.run(command, capture_output=True, text=True, check=True)
            return {"status": "success", "output": result.stdout}
        except subprocess.CalledProcessError as e:
            return {"status": "error", "message": e.stderr}
