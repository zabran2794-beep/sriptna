class AssetManagerError(Exception):
    """Base class untuk error di library ini."""
    pass

class ExecutableNotFoundError(AssetManagerError):
    """Error jika file .exe tidak ditemukan."""
    pass

class ExtractionError(AssetManagerError):
    """Error jika proses ekstraksi gagal."""
    pass
