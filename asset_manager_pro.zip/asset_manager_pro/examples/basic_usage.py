from asset_manager import BundleExtractor

# Inisialisasi
extractor = BundleExtractor()

# Ekstrak file Unity
hasil = extractor.extract("game_data.unity3d", "./output_folder")

if hasil["status"] == "success":
    print("✅ Berhasil mengekstrak aset!")
else:
    print(f"❌ Gagal: {hasil['message']}")
